# loadMoreResults
 It is a simple jQuery plugin that allows you to list the 'list' in the HTML by clicking on the 'load more' button.
